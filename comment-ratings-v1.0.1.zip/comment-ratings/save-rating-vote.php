<?php
include "../../../wp-load.php";
//echo $_GET['comment_id'];


$wp_table = $wpdb->prefix . "comments";
//echo $wp_table;
if($_GET['pilim']==1){
	$sql = $wpdb->prepare(
	"UPDATE $wp_table SET pluses=(pluses+1) WHERE comment_ID=%d",	$_GET['comment_id'] );//увеличиваем количество плюсов на единицу

	$done = $wpdb->query( $sql );
}

if($_GET['pilim']==-1){
	$sql = $wpdb->prepare(
	"UPDATE $wp_table SET minuses=(minuses+1) WHERE comment_ID=%d",	$_GET['comment_id'] );//увеличиваем количество минусов на единицу

	$done = $wpdb->query( $sql );
}
?>