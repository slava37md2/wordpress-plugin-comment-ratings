<?php
/*
Plugin Name: comment-ratings
Plugin URI: https://rimir.com.ua/wp/2017/09/13/wordpress-webcam-comments-plugin-page/
Description: Attach rating to comments and build a new commenting experience.
Version: 1.0.0
Author: Deorditsa Veaceslav
Author URI: https://rimir.com.ua/wp/2017/09/13/wordpress-webcam-comments-plugin-page/
Disclaimer: Use at your own risk. No warranty expressed or implied is provided.
*/

/*
    Copyright 2017 Deorditsa Veacheslav

*/




add_filter('comment_text', 'add_rating_to_comment_text');//добавляем рейтинг комментария
function add_rating_to_comment_text( $comment = '')
{
	global $wpdb;
	$id = get_comment_ID();
	$row = $wpdb->get_row( "SELECT * FROM $wpdb->comments WHERE comment_ID=$id" );
	$rating = $row->pluses - $row->minuses;
	
	if( $rating > 0 ){$rating='+'.$rating;$color='green';}
	if( $rating < 0 ){$color='red';}
	
	$comment .= '<br>Оцените комментарий без регистрации: ..<span id="strelka_vverh'.$id.'"><a href="javascript:void(0);" onclick="ajax(1,'.$id.');"><img src="'.
	site_url().'/wp-content/plugins/comment-ratings/strelka_up.jpg"></a></span> <span id="rating'.$id.'" style="color: '.$color.'" title="Общий рейтинг '.
	$rating.': &uarr;'.$row->pluses.' и &darr;'.$rating = $row->minuses.'">'.
	$rating.'</span> . <span id="strelka_vniz'.$id.'"><a href="javascript:void(0);" onclick="ajax(-1,'.$id.');"><img src="'.site_url().'/wp-content/plugins/comment-ratings/strelka_down.jpg"></a></span><br>';
	return $comment;
}








add_action('comment_form', 'add_ajax_to_comment_form', 99);
function add_ajax_to_comment_form()
{
	$siteurl = site_url();
?>
<script type="text/javascript">
function ajax( plus_ili_minus, comment_id ){
	/*rand = Math.random();
	var date = new Date(new Date().getTime() + 60 * 1000);
	document.cookie = "rand="+rand+"; path=/; expires=" + date.toUTCString();*/

	var xhr = new XMLHttpRequest();
	xhr.open('GET', "<?php echo $siteurl;?>/wp-content/plugins/comment-ratings/save-rating-vote.php?pilim="+plus_ili_minus+'&comment_id='+comment_id, true);
	xhr.send();
	xhr.onreadystatechange = function() {
		if (this.readyState != 4) return;

  // по окончании запроса доступны:
  // status, statusText
  // responseText, responseXML (при content-type: text/xml)

		if (this.status != 200) {
    // обработать ошибку
			alert( 'ошибка: ' + (this.status ? this.statusText : 'запрос не удался') );
			return;
		}
		else //(this.status == 200) 
		{
    // получить результат из this.responseText или this.responseXML
			//alert( this.responseText );
			document.getElementById('strelka_vverh'+comment_id).innerHTML = '';//убираем стрелки
			document.getElementById('strelka_vniz'+comment_id).innerHTML = '';
			if(plus_ili_minus==1)document.getElementById('rating'+comment_id).innerHTML = parseInt(document.getElementById('rating'+comment_id).innerHTML, 10)+1;// изменяем рейтинг
			if(plus_ili_minus==-1)document.getElementById('rating'+comment_id).innerHTML = parseInt(document.getElementById('rating'+comment_id).innerHTML, 10)-1;
			return;
		}
	}
	return;
}
</script>
<?php
}









function create_fields_in_database_table() {//добавляем в таблицу comments поля pluses и minuses
	$db = mysqli_connect("127.0.0.1", "db_user", "db_user_password", "db_name");
	
	

	if (!$db) {
	    echo "Ошибка: Невозможно установить соединение с MySQL.<br>" . PHP_EOL;
	    echo "Код ошибки errno: " . mysqli_connect_errno() ."<br>". PHP_EOL;
	    echo "Текст ошибки error: " . mysqli_connect_error() ."<br>". PHP_EOL;
	    exit;
	}

	global $wpdb;
	$wp_table = $wpdb->prefix . "comments";
	$chkcol = mysqli_query($db, "SELECT * FROM `$wp_table` LIMIT 1");
	$mycol = mysqli_fetch_array($chkcol);
	if(!isset($mycol['pluses']))
		$result = mysqli_query($db, "ALTER TABLE $wp_table ADD pluses smallint UNSIGNED NOT NULL DEFAULT 0") or die(mysqli_error($db));//smallint - 2 байта
	if(!isset($mycol['minuses']))
		$result = mysqli_query($db, "ALTER TABLE $wp_table ADD minuses smallint UNSIGNED NOT NULL DEFAULT 0") or die(mysqli_error($db));//добавляем в таблицу comments поля pluses и minuses
	

}
register_activation_hook( __FILE__, 'create_fields_in_database_table' );
?>
